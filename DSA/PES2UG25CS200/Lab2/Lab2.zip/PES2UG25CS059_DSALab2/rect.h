#ifndef RECT_H
#define RECT_H

typedef struct rectangle{
	int length;
	int breadth;	
} rect;

void CS059_init(rect *r, int l, int b);
int CS059_area(rect *r);
void CS059_disp(rect *r, int area);

#endif