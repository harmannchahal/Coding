#include <stdio.h>
#include "rect.h"

int main(void){
	rect r;
	int l, b, area;
	printf("Enter Length and Breadth of Rectangle: ");
	scanf("%d %d", &l, &b);
	CS059_init(&r, l, b);
	area = CS059_area(&r);
	CS059_disp(&r, area);
}